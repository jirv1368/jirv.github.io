from django.apps import AppConfig


class NcscCvdConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cvd_service'
