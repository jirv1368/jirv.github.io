from django.contrib import admin

from .models import Case

admin.site.register(Case)
