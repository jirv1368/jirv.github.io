# This function will check whether an input is an integer or float and prompt the user.


def integer_check():
  """Input must be an integer"""
  while True:
    try:
      val = int(input("Please enter a number: "))
      return val
    except ValueError:
      print("Invalid number")
      continue
    else:
      break

def float_check():
  """Input must be a float """
  while True:
    try:
      val = float(input("Please enter a decimal number, e.g. 1.1 : "))
      return val
    except ValueError:
      print("Not a valid Number")
      continue
    else:
      break

def end_spacer():
  """This is a spacer"""
  print("********************************")
  print("")
  return
