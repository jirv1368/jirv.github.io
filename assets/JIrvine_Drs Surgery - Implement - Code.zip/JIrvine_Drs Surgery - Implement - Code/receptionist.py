# This is the class for the receptionist that uses
# inheritance from the appointment_list class.

import appointment_list

class Receptionist:
  """Creates a new receptionist"""
  def __init__(self, name, staff_id):
    self.name = name
    self.staff_id = staff_id
  
  def appt_booking(self, patient, doctor, appoint_time):
    """The receptionist books apointments"""
    doctor.appt_time.appt_add(patient, appoint_time)

  def appt_cancel(self, doctor, appointment):
    """Cancel appointment"""
    doctor.appt_time.appt_cancel(appointment)
