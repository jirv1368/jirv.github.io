# This is the class for a prescription that uses inheritance from
# the patient class.

import patient

class Prescription:
  """This adds a new prescription."""
  def __init__(self, type, patient, amount, dose_amount, doctor=None):
    self.type = type
    self.patient = patient
    self.doctor = doctor 
    self.amount = amount
    self.dose_amount = dose_amount

