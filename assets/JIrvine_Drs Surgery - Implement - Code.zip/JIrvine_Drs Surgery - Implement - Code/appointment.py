# This is the class for a an appointment that uses
# inheritance from the appointment_list class.

import appointment_list

class Appointment:
  """Class to create instance of appointment"""
  def __init__(self, surgery_emp, patient):
    self.surgery_emp = surgery_emp
    self.patient = patient

    
