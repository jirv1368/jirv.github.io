# This is the class for Healthcare Professionals that uses
# inheritance from the patient, prescription and input_checker classes.

import patient
import prescription
import input_checker

class Hcare_profs():
  """Creates new Dr Surgery staff member"""
  def __init__(self, name, staff_id, appt_time):
    self._name = name
    self._staff_id = staff_id
    self.appt_time = appt_time

  @property
  def staff_id(self):
    return self._staff_id

  @property
  def name(self):
    return self._name

  def __str__(self):
    return "{}".format(self.name)

class Doctor(Hcare_profs):
  def __init__(self, name, staff_id, appt_time):
    Hcare_profs.__init__(self, name, staff_id, appt_time)

  def prescrpn_issue(self, patient):
    """Drs issue prescriptions."""
    doctor = self.name
    patient = patient
    prescription_type = input("Please enter prescription: ")
    print("Please enter the amount") 
    amount = input_checker.integer_check()
    print("Please enter dose amount (ml) ")
    dose_amount = input_checker.float_check()
    doctor = self.name
    new_prescription = prescription.Prescription(prescription_type, patient, amount, dose_amount, self.name)
    prescription_val = len(patient.prescription_list) + 1
    prescription_dict = {'val': prescription_val, 'med': new_prescription}
    patient.prescription_list.append(prescription_dict)
    return

  def patients_list(self, patients):
    """Outputs a list of patients that is registered with a Dr."""
    my_patients = []
    for p in patients:
      if str(p.get('patient').doctor) == str(self.name):
        my_patients.append(p)
    return my_patients

 # Nurse inherits methods and propoerties of Hcare_prod class

class Nurse(Hcare_profs):
  def __init__(self):
    super().__init__()
