# This is a list of apointments with 15 minutes between each,
# the argument False means the time is booked and True that it is available.

class Appointment_List:
  """Doctors can manage appointments from here."""
  def __init__(self):

    self.appointment_list = [
      {'val': 1, 'time': "09:00", 'available': False, 'patient': 'Mr Jack Brown'}, 
      {'val': 2, 'time': "09:15", 'available': True, 'patient': ''},
      {'val': 3, 'time': "09:30", 'available': False, 'patient': 'Mrs Val Pink'},
      {'val': 4, 'time': "09:45", 'available': True, 'patient': ''},
      {'val': 5, 'time': "10:00", 'available': False, 'patient': 'Another patient'},
      {'val': 6, 'time': "10:15", 'available': True, 'patient': ''},
      {'val': 7, 'time': "10:30", 'available': True, 'patient': 'Another patient'},
      {'val': 8, 'time': "10:45", 'available': False, 'patient': 'Mr Peter Green'},
      {'val': 9, 'time': "11:00", 'available': True, 'patient': ''},
      {'val': 10, 'time': "11:15", 'available': False, 'patient': 'Another patient'},
      {'val': 11, 'time': "11:30", 'available': False, 'patient': 'Another patient'},
      {'val': 12, 'time': "11:45", 'available': False, 'patient': 'Another patient'},
      {'val': 13, 'time': "12:00", 'available': True, 'patient': ''},
      {'val': 14, 'time': "12:15", 'available': False, 'patient': 'Another patient'},
      {'val': 15, 'time': "12:30", 'available': False, 'patient': 'Another patient'},
      {'val': 16, 'time': "13:30", 'available': True, 'patient': ''},
      {'val': 17, 'time': "13:45", 'available': True, 'patient': ''},
      {'val': 18, 'time': "14:00", 'available': False, 'patient': 'Another patient'},
      {'val': 19, 'time': "14:15", 'available': True, 'patient': ''},
      {'val': 20, 'time': "14:30", 'available': False, 'patient': 'Another patient'},
      {'val': 21, 'time': "14:45", 'available': True, 'patient': ''},
      {'val': 22, 'time': "15:00", 'available': False, 'patient': 'Another patient'},
      {'val': 23, 'time': "15:15", 'available': True, 'patient': ''},
      {'val': 24, 'time': "15:30", 'available': False, 'patient': 'Another patient'},
      {'val': 25, 'time': "15:45", 'available': True, 'patient': ''},
      {'val': 26, 'time': "16:00", 'available': True, 'patient': ''},
      {'val': 27, 'time': "16:15", 'available': False, 'patient': 'Another patient'},
      {'val': 28, 'time': "16:30", 'available': True, 'patient': ''},
      {'val': 29, 'time': "16:45", 'available': False, 'patient': 'Another patient'},
      {'val': 30, 'time': "17:00", 'available': False, 'patient': 'Another patient'},
      {'val': 31, 'time': "17:15", 'available': True, 'patient': ''},
      {'val': 32, 'time': "17:30", 'available': False, 'patient': 'Another patient'},
      {'val': 33, 'time': "17:45", 'available': True, 'patient': ''},
      {'val': 34, 'time': "18:00", 'available': False, 'patient': 'Another patient'},
    ]

  def appt_checker(self):
    """This loops through the list and shows availability"""
    apps_avail = []
    print("The available times are: ")
    for i in self.appointment_list:
      if i.get('available') == True:
        apps_avail.append(i)
    return apps_avail

  def appt_name(self, patient):
    """This is patient appointments argument."""
    appointments = []
    for i in self.appointment_list:
      if i.get('patient') == patient:
        appointments.append(i)
    return appointments

  def appt_add(self, patient, appoint_time):
    """A new appointment is added to the list"""
    for i in self.appointment_list:
      if appoint_time.get('val') == i.get('val'):
        i.update({'available': False, 'patient': patient})    

  def appt_cancel(self, appointment):
    """This cancels an appointment"""
    for i in self.appointment_list:
      if appointment.get('val') == i.get('val'):
        i.update({'available': True, 'patient': ''})

  def display_appt(self):
    """This diplays all the appointments if the argument is True"""
    for i in self.appointment_list:
      if i.get('available') == True:
        print(("{}:                        ").format(i.get('time')))
      else:
        print(("{}: {}").format(i.get('time'), i.get('patient')))
