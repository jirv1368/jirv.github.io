# System classes to be imported
import patient 
import hcare_profs
import receptionist 
import appointment_list
import prescription
import input_checker

# Global variables
patients = []
doctors = []
prescription_list = []
patient_num = 1

appoints = appointment_list.Appointment_List()

# This code is adding the details for 3 doctors, using a txt file or csv would be better.
dr1 = hcare_profs.Doctor("Dr David Who", "1 Smith Street", appoints)
doctors.append({'val': 1, 'doc': dr1})
dr2 = hcare_profs.Doctor("Dr Ian What ", "8 Medical Street", appoints)
doctors.append({'val': 2, 'doc': dr2})
dr3 = hcare_profs.Doctor("Dr Sam Where", "12 Lost Road", appoints)
doctors.append({'val': 3, 'doc': dr3})

# This code is adding the details for 3 patients, again using a txt file or csv would be better.
patnt1 = patient.Patient("Mr", "Jack", "Brown", "15 Brown Street", "02339747563", "12/02/1999", dr1)
patients.append({'val': 1, 'patient': patnt1})
patnt2 = patient.Patient("Mr", "Peter", "Green", "12 Green Street", "02345643328", "22/12/1978", dr2)
patients.append({'val': 2, 'patient': patnt2})
patnt3 = patient.Patient("Mrs", "Val", "Pink", "90 Pink Street", "02365098762", "05/06/1985", dr3)
patients.append({'val': 3, 'patient': patnt3})

# This code is adding the details of prescriptions for patients, again using a txt file or csv would be better.
prescpn1 = prescription.Prescription("Antibiotics", patnt1, 4, 23.5, dr1)
patnt1.prescription_list.append({'val': 1, 'med': prescpn1})
prescpn2 = prescription.Prescription("Bisoprolol Beta-Blockers", patnt1, 2, 16.8, dr1)
patnt1.prescription_list.append({'val': 2, 'med': prescpn2})
prescpn3 = prescription.Prescription("Corticosteroids Inhaler", patnt1, 4, 15.7, dr1)
patnt1.prescription_list.append({'val': 3, 'med': prescpn3})
prescpn3 = prescription.Prescription("Simvastatin Statins", patnt2, 10, 8.2, dr2)
patnt2.prescription_list.append({'val': 1, 'med': prescpn3})

# This code will add somee trial data to the program for a receptionist. 
reception = receptionist.Receptionist("Mrs C Smith", "999")

def main_menu():

  print("************************************")
  print("* Welcome to The Essex Drs Surgery *")
  print("************************************")
  print("*          Admin Portal            *")
  print("************************************")
  print("1: Register Patient")
  print("2: Appointments")
  print("3: Doctors Login")
  
  user = input_checker.integer_check()

  # This is the code to add a new patient.
  if user == 1:

    title = str(input("Please enter title e.g. Mr, Mrs, Ms, Miss etc. "))
    name = str(input("Please enter your first name: "))
    surname = str(input("Please enter your surname: "))
    address = str(input("Please enter your full address with post code: "))
    phone = str(input("Please enter your phone number: "))
    dob = str(input("Please enter your date of birth as DD/MM/YYYY e.g. 10/12/1982 : "))

    print("Please select a doctor ")
    for doc in doctors:
      print(("{}: {}").format(doc.get('val'), doc.get('doc').name))
    doctor = input_checker.integer_check()
    selected_doctor = ''
    for i in doctors:
      if doctor == i.get('val'):
        selected_doctor = i.get('doc')
        print(("Selected doc: {}").format(i.get('doc').name))

        # A Dr can only have a maximum of 500 patients.
        if len(selected_doctor.patients_list(patients)) <= 500: 
          new_patient = patient.Patient(title,name,surname,address,phone,dob,selected_doctor)
          patients.append({'val': len(patients) + 1, 'patient': new_patient})
          print(("New patient: {}").format(patients[len(patients)-1].get('patient').name))
          input_checker.end_spacer()
          main_menu()
        else:
          print("Please choose another Dr")
          main_menu()
    input_checker.end_spacer()
    print("Invalid input")
    main_menu()



  # This will allow an existing patient to login
  elif user == 2:
    print("Please a name by typing the number: ")
    for p in patients:
      print(("{}: {}").format(p.get('val'), p.get('patient').name))
    print("")
    choice = input_checker.integer_check()
    if choice <= len(patients):
      for pat in patients:
        if choice == pat.get('val'):
          live_patnt = pat.get('patient')
          input_checker.end_spacer()
          patnt_choice(live_patnt)
    else:
      print("")
      print("Please try again.")
      main_menu()


  # This will allow Drs to login
  elif user == 3:
    input_checker.end_spacer()
    print("Please select your name from the list: ")
    for doc in doctors:
      print(("{}: {}").format(doc.get('val'),doc.get('doc').name))
    print("")
    choice = input_checker.integer_check()
    if choice > 0 & choice <= len(doctors):
      for d in doctors:
        if choice == d.get('val'):
          live_dr = d.get('doc')
          input_checker.end_spacer()
          print(("Welcome {}").format(live_dr.name))
          input_checker.end_spacer()
          dr_choice(live_dr)
      main_menu()
    else:
      print("")
      print("Please enter a number.")
      main_menu()

  else:
    print("")
    print("Please login again.")
    main_menu()



def patnt_choice(patient):
  # This menu should be displayed.
  print("*************************************")
  print("*Welcome to the Patient Admin Portal*")
  print("*************************************")
  print("1: Show prescriptions")
  print("2: Book an Appointment")
  print("3: Cancel appointment ")

  prescription_choice = input_checker.integer_check()
  input_checker.end_spacer()
  if prescription_choice == 1:
    if patient.prescription_list:
      for i in patient.prescription_list:
        print(("{}: {} - Repeat prescriptions left: {}").format(i.get('val'), i.get('med').type, i.get('med').amount))
      option = input_checker.integer_check()
      if option <= len(patient.prescription_list):
        for j in patient.prescription_list:
          if option == j.get('val'):
            if j.get('med').amount != 0:
              j.get('med').amount -= 1
              print(("{} ordered").format(j.get('med').type))
              print("")
              print(("You have {} of {} left").format(j.get('med').amount, j.get('med').type))
              print("")
              input_checker.end_spacer()
              patnt_choice(patient)
            elif j.get('med').amount == 0:
              print(("No more {} left, please see your doctor. {}").format(j.get('med').type, patient.doctor))
              patnt_choice(patient)
      else:
        print("")
        print("Incorrect number entered!")
        input_checker.end_spacer()
        patnt_choice(patient)
    else:
      print("You have no active prescriptions.")
      input_checker.end_spacer()
      patnt_choice(patient)
  
  # This will allow an appointment to be booked.
  elif prescription_choice == 2:
    available = patient.doctor.appt_time.appt_checker()
    for i in available:
      print(("{}: {}").format(i.get('val'), i.get('time')))
    appoint_time = input_checker.integer_check()
    input_checker.end_spacer()
    for j in available:
      if appoint_time == j.get('val'):
        patient.appointment_required(j, reception)
        print(("Your appointment time is {}").format(j.get('time')))
        patnt_choice(patient)
    print("")
    print("Incorrect input!")
    patnt_choice(patient)


  
  # This will allow an appointment to be cancelled.
  elif prescription_choice == 3:
    appointments = patient.doctor.appt_time.appt_name(patient.name)
    if appointments:
      print('You have appointment/s for: ')
      for i in appointments:
        print(("{}: {}").format(i.get('val'), i.get('time')))
      print("Enter a number to cancel the appointment.")
      chosen = input_checker.integer_check()
      for i in appointments:
        if chosen == i.get('val'):
          reception.appt_cancel(patient.doctor, i)
          input_checker.end_spacer()
          print("Appointment cancelled")
          input_checker.end_spacer()
          patnt_choice(patient)
      print("Invalid option")
      patnt_choice(patient)
    else:
      print("No appointments are booked.")
      input_checker.end_spacer()
      patnt_choice(patient)
      
      

  # This will take you back to the menu
  elif prescription_choice == 4:
    main_menu()
  
  else: 
    print("")
    print("Incorrect selection, please retry!")
    input_checker.end_spacer()
    patnt_choice(patient)



def dr_choice(doctor):
  # This menu should be displayed.
  print("********************************")
  print("*Welcome to the Doctors Portal*")
  print("********************************")
  print("1: View appointments")
  print("2: Prescriptions")
  print("3: Exit menu ")

  doctor_choice = input_checker.integer_check()
  input_checker.end_spacer()



  # This will allow a Dr to see a list of appointments
  if doctor_choice == 1:
    doctor.appt_time.display_appt()
    input_checker.end_spacer()
    dr_choice(doctor)



  # This allows a Dr to write and authoriise a prescription
  elif doctor_choice == 2:
    print("Select patient: ")
    patient_list = []
    for p in patients:
      patient_list.append(p)
    list_patients = doctor.patients_list(patient_list)
    for pat in list_patients:
      print(("{}: {}").format(pat.get('val'), pat.get('patient').title))
      print(("{}: {}").format(pat.get('val'), pat.get('patient').name))
      print(("{}: {}").format(pat.get('val'), pat.get('patient').surname))
      print(("{}: {}").format(pat.get('val'), pat.get('patient').dob))
    choice = input_checker.integer_check()
    input_checker.end_spacer()
    for i in list_patients:
      if choice == int(i.get('val')):
        doctor.prescrpn_issue(i.get('patient'))
        dr_choice(doctor)

    print("")
    print("Error, please try again!")
    input_checker.end_spacer()
    dr_choice(doctor)

  elif doctor_choice == 3:
    main_menu()

  else:
    print("")
    print("Incorrect selection!")
    main_menu()      

main_menu()
  
