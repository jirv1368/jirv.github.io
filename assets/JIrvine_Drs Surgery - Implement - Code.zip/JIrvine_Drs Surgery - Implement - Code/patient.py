# This is the class for patients that uses
# inheritance from the prescription and receptionist classes.

import prescription
import receptionist

patient_list = []

class Patient:
  """Create a new instance of a patient"""
  def __init__(self, title, name, surname, address, phone, dob, doctor):
    self.title = title
    self._name = name
    self.surname = surname
    self.address = address
    self.phone = phone
    self.dob = dob
    self._doctor = doctor
    self.prescription_list = []

  @property
  def doctor(self):
    return self._doctor

  @property
  def name(self):
    return self._name

  def prescription_required(self):
    """Display prescriptions for patient"""

    prescription_type = eval(input("""
Prescriptions:
1: Prescriptions
2: Repeat prescription required
"""))
    if prescription_type == 1:

      return
    elif prescription_type == 2:
      if self.prescription_list:
        print("This is your prescriptions: ")
        for x in self.prescription_list:
          print((x.patient))
      else:
        print("You have no prescriptions.")
        self.request_prescription()

  def appointment_required(self, appoint_time, reception):
    reception.appt_booking(self.title, self.name, self.surname, self.doctor, appoint_time)
